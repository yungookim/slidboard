SLENDER (v0.9.1)
----------------

Controls (default):

*  Mouse -- Look around
*  W,A,S & D -- Move
*  Left Shift -- Sprint
*  Left Mouse Click -- Pick up pages
*  Right Mouse Click -- Flashlight
*  Q & E -- Zoom in/out


Tips:

*  Do not look at the enemy for too long, or you will lose.
*  Your flashlight has a limited battery; turn it off from time to time to save it.
*  The more you sprint, the lower your maximum stamina becomes, so sprint only when you need to.


UPDATES (v0.9.1)
----------------

*  Turning off the flashlight reduces how fast static will build when looking at the enemy (effectively doubles
your distance for calculation purposes); also, causes the enemy's movement to be slightly more erratic (less
likely to 'jump' directly towards you)
*  Decreased battery life slightly (it should still last long enough for a full game)
*  Replaced textures on the pillars and cross-wall areas; previous textures were causing startup lag
*  Slightly increased walk/run speed, but slightly increased enemy's movement speed to compensate


CREDITS
-------

*  GAME DESIGN & PROGRAMMING
**  Mark J. Hadley


*  MUSIC & SOUND
**  Mark J. Hadley


*  MODELS
**  Pau Cano
**  Universal Image
**  Unity Technologies
**  VIS Games
**  Profi Developers


This game is copyright 2012 by Mark J. Hadley And Parsec Productions.  This is a free, non-profit game, so you
should not be charged by anyone for this.  Comments are welcome at: AgentParsec@gmail.com